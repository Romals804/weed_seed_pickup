local spawnedProps = {}
local canInteract = true

function spawnWeedProps()
    RequestModel(Config.Prop)
    while not HasModelLoaded(Config.Prop) do Wait(0) end

    for _, pos in ipairs(Config.Positions) do
        local prop = CreateObject(Config.Prop, pos.x, pos.y, pos.z - 1.0, false, true, false)
        SetEntityHeading(prop, 0.0)
        FreezeEntityPosition(prop, true)
        table.insert(spawnedProps, prop)

        exports.ox_target:addLocalEntity(prop, {
            {
                label = 'Sesbírat semínka trávy',
                icon = 'fas fa-seedling',
                distance = Config.TargetDistance,
                onSelect = function()
                    if not canInteract then return end
                    canInteract = false
                    local playerPed = PlayerPedId()

                    TaskStartScenarioInPlace(playerPed, 'world_human_gardener_plant', 0, true)
                    exports.ox_lib:progressBar({
                        duration = 15000,
                        position = 'bottom',
                        label = 'Sbíráš semínka...',
                        useWhileDead = false,
                        canCancel = false,
                        disable = { move = true, car = true, combat = true }
                    })

                    ClearPedTasks(playerPed)

                    -- Dej semínka
                    local amount = math.random(1, 5)
                    TriggerServerEvent('weed:giveSeeds', amount)

                    -- Odstraň prop
                    DeleteEntity(prop)

                    -- Volitelně můžeš počkat a zase ho vytvořit
                    Wait(Config.Cooldown * 1000)
                    canInteract = true
                    spawnSingleWeedProp(pos)
                end
            }
        })
    end
end

function spawnSingleWeedProp(pos)
    RequestModel(Config.Prop)
    while not HasModelLoaded(Config.Prop) do Wait(0) end

    local prop = CreateObject(Config.Prop, pos.x, pos.y, pos.z - 1.0, false, true, false)
    SetEntityHeading(prop, 0.0)
    FreezeEntityPosition(prop, true)
    table.insert(spawnedProps, prop)

    exports.ox_target:addLocalEntity(prop, {
        {
            label = 'Sesbírat semínka trávy',
            icon = 'fas fa-seedling',
            distance = Config.TargetDistance,
            onSelect = function()
                if not canInteract then return end
                canInteract = false
                local playerPed = PlayerPedId()

                TaskStartScenarioInPlace(playerPed, 'world_human_gardener_plant', 0, true)
                exports.ox_lib:progressBar({
                    duration = 15000,
                    position = 'bottom',
                    label = 'Sbíráš semínka...',
                    useWhileDead = false,
                    canCancel = false,
                    disable = { move = true, car = true, combat = true }
                })

                ClearPedTasks(playerPed)

                local amount = math.random(1, 5)
                TriggerServerEvent('weed:giveSeeds', amount)

                DeleteEntity(prop)

                Wait(Config.Cooldown * 1000)
                canInteract = true
                spawnSingleWeedProp(pos)
            end
        }
    })
end

CreateThread(function()
    spawnWeedProps()
end)
