ESX = exports["es_extended"]:getSharedObject()

RegisterServerEvent('weed:giveSeeds', function(amount)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer then
        xPlayer.addInventoryItem('weed_og_seed', amount)
    end
end)
